#!/bin/bash

export ANSIBLE_FORCE_COLOR=true
export ANSIBLE_HOST_KEY_CHECKING=False
red=`tput setaf 1`
green=`tput setaf 2`
reset=`tput sgr0`


set -x
rm -rf inventory/prodaggregation
curl --get http://lead.birdeye.com/aggregation/serverlist?env=prod | tr " " "\n" > inventory/prodaggregation
sed -i '1s/^/[aggregation]\n/' inventory/prodaggregation


    ansible-playbook checktomcat  --private-key=/var/lib/jenkins/ssh-keys/devops_rsa -u devops -i inventory
    
    echo "Build Completed"

#Below code not required to be enbabled here####
#if [ $? -ne 0 ]
#then
#        echo "${red}Build failed , Check build logs" ${reset}
#        exit 1
#else
#        echo "${green}Finished Build at " `date` ${reset}
#fi

