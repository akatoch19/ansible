          This Playbook is to install SSL certificate 
          Use the build job "http://jenkins.birdeye.internal/view/DevOps/job/devops-paid-ui-ssl-installation/"
          and start build with parameter and enter the domain name for which you want to install the SSL. 
          
          Upon successful installation of SSL.
          
          Add the domain to https://sslmonitor.birdeye.com/ for SSL monitoring. 
