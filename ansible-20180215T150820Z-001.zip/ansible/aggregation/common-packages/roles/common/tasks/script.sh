#!/bin/bash
sudo cd /home/aggre
sudo npm install crack
sudo pip install -U pip setuptools
#sudo pip install Scrapy
#sudo pip install cryptography
