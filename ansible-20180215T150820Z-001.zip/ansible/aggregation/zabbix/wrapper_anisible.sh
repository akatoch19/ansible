#!/bin/bash

export ANSIBLE_FORCE_COLOR=true
export ANSIBLE_HOST_KEY_CHECKING=False
red=`tput setaf 1`
green=`tput setaf 2`
reset=`tput sgr0`



ansible-playbook  zabbixaggregation.yml  --private-key=/var/lib/jenkins/ssh-keys/devops_rsa -u devops -i inventory --extra-vars "hostmetadata=${2} zabbixhost='aggrezabbix.birdeye.com' hostname=${1} SA=${3} user=devops"



#if [ $? -ne 0 ]
#then
#        echo "${red}Build failed , Check build logs" ${reset}
#        exit 1
#else
#        echo "${green}Finished Build at " `date` ${reset}
#fi

