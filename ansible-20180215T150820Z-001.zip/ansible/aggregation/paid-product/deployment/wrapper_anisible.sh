#!/bin/bash

export ANSIBLE_FORCE_COLOR=true
export ANSIBLE_HOST_KEY_CHECKING=False
red=`tput setaf 1`
green=`tput setaf 2`
reset=`tput sgr0`


set -x
rm -rf inventory/prodaggregation
curl --get http://lead.birdeye.com/aggregation/serverlist?env=prod | tr " " "\n" > inventory/prodaggregation
sed -i '1s/^/[aggregation]\n/' inventory/prodaggregation

if [ "X$1" = "Xyes" ];then
   ssh -o StrictHostKeyChecking=no -i ~/papi.pem ubuntu@54.241.28.95 " sudo /etc/init.d/cron stop"
   ssh -o StrictHostKeyChecking=no -i ~/papi.pem ubuntu@54.241.28.95 " sudo /etc/init.d/monit stop"
   /usr/bin/curl -H "content-type: application/json" -H "accept:application/json" -X POST -sL -w "%{http_code}" "https://quartzelb.birdeye.com/resources/v1/quartz/pauseall"

    result="1"
    while [ "$result" != "0" ]
     do
     result=$(mysql bazaarify -u deployment -pRWKANyj5AfFdUVg -hquartzdb.birdeye.com  -se "SELECT count(*) FROM QRTZ_FIRED_TRIGGERS;" | tail -1 )
     sleep 20
    done


ansible-playbook aggregationwithrestart.yml --private-key=/var/lib/jenkins/ssh-keys/devops_rsa -u devops -i inventory
sleep 5;
for servers in `cat aggregationwithrestart.retry`
do 
wget -qO- "http://lead.birdeye.com/aggregation/updateserver?env=prod&ip="$servers"&status=0&update_status=0&remark=SSH Failed" &> /dev/null;
done
sleep 5;
 mysql  bazaarify -u deployment -pRWKANyj5AfFdUVg -hquartzdb.birdeye.com  -se "truncate table QRTZ_PAUSED_TRIGGER_GRPS;"
 mysql  bazaarify -u deployment -pRWKANyj5AfFdUVg -hquartzdb.birdeye.com  -se "update QRTZ_TRIGGERS set trigger_state='WAITING' where trigger_state='PAUSED';";
 ssh -o StrictHostKeyChecking=no -i ~/papi.pem ubuntu@54.241.28.95 " sudo /etc/init.d/cron start"
 ssh -o StrictHostKeyChecking=no -i ~/papi.pem ubuntu@54.241.28.95 " sudo touch /tmp/check_cron"
 ssh -o StrictHostKeyChecking=no -i ~/papi.pem ubuntu@54.241.28.95 " sudo /etc/init.d/monit start"

echo "hi"
fi

if [ "X$1" = "Xrefresh" ];then

ansible-playbook  aggregationwithrefresh.yml  --private-key=/var/lib/jenkins/ssh-keys/devops_rsa -u devops -i inventory
for servers in `cat aggregationwithrefresh.retry`
do
wget -qO- "http://lead.birdeye.com/aggregation/updateserver?env=prod&ip="$servers"&status=0&update_status=0&remark=SSH Failed" &> /dev/null;
done
fi


if [ "X$1" = "Xno" ];then

ansible-playbook  aggregation.yml  --private-key=/var/lib/jenkins/ssh-keys/devops_rsa -u devops -i inventory
for servers in `cat aggregation.retry`
do
wget -qO- "http://lead.birdeye.com/aggregation/updateserver?env=prod&ip="$servers"&status=0&update_status=0&remark=SSH Failed" &> /dev/null;
done
fi




#if [ $? -ne 0 ]
#then
#        echo "${red}Build failed , Check build logs" ${reset}
#        exit 1
#else
#        echo "${green}Finished Build at " `date` ${reset}
#fi

