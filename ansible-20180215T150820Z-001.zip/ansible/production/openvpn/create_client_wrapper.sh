#!/bin/bash
#/bin/bash deploy_wrapper.sh ${USER_NAME} ${ACCESS_TYPE} ${EMAIL}

export ANSIBLE_FORCE_COLOR=true
export ANSIBLE_HOST_KEY_CHECKING=False

red=`tput setaf 1`
green=`tput setaf 2`
reset=`tput sgr0`
UserName=${1}
EMAIL=${2}

echo -e "\nUser=$UserName\nEmail=$EMAIL"

Ansible=`which ansible-playbook`
Pass=`date +%s | sha256sum | base64 | head -c 12 ; echo`

echo $Pass
echo "+++++++++++++++++++++++++++++++++"
echo -e '[openvpn]\n13.56.51.81' > inventory/hosts
$Ansible -v -e 'host_key_checking=False' openvpn_create_client.yml --private-key=/var/lib/jenkins/ssh-keys/devops_rsa -u devops -i inventory --extra-vars "Client_Name=${UserName} Client_Password=${Pass} Client_Email=${EMAIL} openvpn_dns_name=vpn.birdeye.com"

#echo "${EMAIL} ${UserName} ${Pass}"
exit
if [ $? -ne 0 ]
then
	echo "${red}Build failed , Check build logs" ${reset}
        exit 1
else
        /usr/bin/python /var/lib/jenkins/scripts/access-sendmail.py ${AccessType} ${EMAIL} ${UserName} ${Pass}
	echo "${green}Finished Build at " `date` ${reset}
fi
