#!/bin/bash
#/bin/bash deploy_wrapper.sh ${USER_NAME} ${ACCESS_TYPE} ${EMAIL}

export ANSIBLE_FORCE_COLOR=true
export ANSIBLE_HOST_KEY_CHECKING=False

red=`tput setaf 1`
green=`tput setaf 2`
reset=`tput sgr0`
UserName=${1}
AccessType=${2}
EMAIL=${3}

echo -e "\nUserName=${1}\nAccessType=${2}\nEMAIL=${3}\n"

Ansible=`which ansible-playbook`
Pass=`date +%s | sha256sum | base64 | head -c 12 ; echo`

if [ "$AccessType" == "MySQL" ]
then 
  echo 'db.birdeye.com' >> inventory/hosts #Production db IP
#  echo -e '\n52.53.121.194' >> inventory/hosts  #Slave Db IP 2
#  echo -e '\n13.56.162.215' >> inventory/hosts #Slave db IP 1
  echo -e '\n52.90.160.80' >> inventory/hosts #techsupport db IP
#  echo -e '\n13.56.217.220' >> inventory/hosts #Social DB IP
  echo -e '\n54.215.1.164' >> inventory/hosts #DemoDB IP
  echo -e '\n54.153.40.57' >> inventory/hosts #Freedb IP Master
#  echo -e '\n54.153.89.136' >> inventory/hosts #FreeDB Slave IP
  echo -e '\n52.8.175.124' >> inventory/hosts #Bam DB IP
#  echo -e '\nprod-blog-db.birdeye.com' >> inventory/hosts #Blog IP
  un=`echo ${UserName} | head -c 15`
  echo $un
  $Ansible -e 'host_key_checking=False' mysql.yaml --private-key=/var/lib/jenkins/ssh-keys/devops_rsa -u devops -i inventory --extra-vars "MySQLRootPassword='bazaar360' MySQLLoginUser='root' MySQLUserName=${un} MySQLRandomPassword=${Pass} user='devops'"
elif [ "$AccessType" == "MongoDB" ]
then
  echo 'prod-mongo.birdeye.com' >> inventory/hosts
  $Ansible -e 'host_key_checking=False' mongodb.yaml --private-key=/var/lib/jenkins/ssh-keys/devops_rsa -u devops -i inventory --extra-vars "MongoDBLoginUser='root' MongoDBLoginPassword='bazaar360' MongoDBName='eyelytics' MongoDBUserName=${UserName} MongoRandomPassword=${Pass} user='devops'"
elif [ "$AccessType" == "Twiki" ]
then
  echo 'twiki.birdeye.com' >> inventory/hosts
  UserName='Please create your user account at URL https://twiki.birdeye.com/twiki/bin/view/TWiki/TWikiRegistration make sure you enter your First name and last name properly. Also use capital later for First charachter in your First and Last name'
  Pass='You can reset your password later any time goingto URLhttps://twiki.birdeye.com/twiki/bin/view/TWiki/ChangePassword'
elif [ "$AccessType" == "SSHBastion" ]
then
  echo 'jumpbox.birdeye.com' >> inventory/hosts
  $Ansible -e 'host_key_checking=False' bastion.yaml --private-key=/var/lib/jenkins/ssh-keys/devops_rsa -u ec2-user -i inventory --extra-vars "UserName=${UserName} RandomPassword=${Pass}"
elif [ "$AccessType" == "InternalJenkins" ] 
then
  echo 'Adding user to internal jenkins'
  sed -i "s|USERNAME|$UserName|g" script.groovy
  sed -i "s|PASSWORD|$Pass|g" script.groovy
#  jenkins_url='http://jenkins.birdeye.internal'
  jenkins_url='http://10.0.1.108:8080'
  username='beadmin'
  token='98f64d8556e12f7f3580e5e34e2e6edd'
  CRUMB=$(curl -k --user $username:$token $jenkins_url/crumbIssuer/api/xml?xpath=concat\(//crumbRequestField,%22:%22,//crumb\))
#  curl -v -X POST 'http://beadmin:$token@10.0.1.108:8080/scriptText' -H "$CRUMB" -d "script=$(cat script.groovy)"
  curl -kv -X POST -H "$CRUMB" $jenkins_url/script \
  --user $username:$token \
  --data-urlencode "script=$(< ./script.groovy)"
else
  echo -e "\nWrong input provided please check!!\n"
  exit 1
fi
#Calling sendmail python function to send notification to user
#    AccessType = sys.argv[1]
#    Email = sys.argv[2]
#    Username = sys.argv[3]
#    Pass = sys.argv[4]


# Change to directory for Deployment

if [ $? -ne 0 ]
then
	echo "${red}Build failed , Check build logs" ${reset}
        exit 1
else
#        /usr/bin/python /var/lib/jenkins/scripts/access-sendmail.py ${AccessType} ${EMAIL} ${UserName} ${Pass}
        /usr/bin/python access-sendmail.py ${AccessType} ${EMAIL} ${UserName} ${Pass}
	echo "${green}Finished Build at " `date` ${reset}
fi
