import jenkins.model.*
import hudson.security.*
import java.util.*
import com.michelin.cio.hudson.plugins.rolestrategy.*
import java.lang.reflect.*

def instance = Jenkins.getInstance()

def hudsonRealm = new HudsonPrivateSecurityRealm(false)
hudsonRealm.createAccount("USERNAME","PASSWORD")
instance.setSecurityRealm(hudsonRealm)
instance.save()

def roleName = "developer"
def userName = "USERNAME"

def findGuestRoleEntry(grantedRoles, roleName)
{
  for (def entry : grantedRoles)
  {
    Role role = entry.getKey()

    if (role.getName().equals(roleName))
    {
      return entry
    }
  }

  return null
}

def authStrategy = Jenkins.instance.getAuthorizationStrategy()

if(authStrategy instanceof RoleBasedAuthorizationStrategy){
  RoleBasedAuthorizationStrategy roleAuthStrategy = (RoleBasedAuthorizationStrategy) authStrategy

  // Make constructors available
  Constructor[] constrs = Role.class.getConstructors();
  for (Constructor<?> c : constrs) {
    c.setAccessible(true);
  }
  // Make the method assignRole accessible
  Method assignRoleMethod =  RoleBasedAuthorizationStrategy.class.getDeclaredMethod("assignRole", String.class, Role.class, String.class);
  assignRoleMethod.setAccessible(true);

  def grantedRoles = authStrategy.getGrantedRoles(RoleBasedAuthorizationStrategy.GLOBAL);
  if (grantedRoles != null)
  {
    println "Got grantedRoles for " + RoleBasedAuthorizationStrategy.GLOBAL

    def roleEntry = findGuestRoleEntry(grantedRoles, roleName);
    if (roleEntry != null)
    {
      println "Found role " + roleName

      def sidList = roleEntry.getValue()
      if (sidList.contains(userName))
      {
        println "User " + userName + " already assigned to role " + roleName
      } else {
        println "Adding user " + userName + " to role " + roleName
       roleAuthStrategy.assignRole(RoleBasedAuthorizationStrategy.GLOBAL, roleEntry.getKey(), userName);
        println "OK"
      }

      Jenkins.instance.save()
    } else {
      println "Unable to find role " + roleName
    }
  } else {
    println "Unable to find grantedRoles for " + RoleBasedAuthorizationStrategy.GLOBAL
  }
} else {
  println "Role Strategy Plugin not found!"
}

