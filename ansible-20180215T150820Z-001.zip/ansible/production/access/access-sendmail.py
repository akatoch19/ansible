#!/usr/bin/python
import time,sys
import base64,os
import datetime
import smtplib
from string import Template

from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

#send mail
def sendmail(status=""):
#    encodedcontent = base64.b64encode(filecontent)  # base64
#    filename = os.path.basename(filename)
    AccessType = sys.argv[1]
    Email = sys.argv[2]
    Username = sys.argv[3]
    Pass = sys.argv[4]
    print "in sendmail function"
    SERVER = "localhost"
    FROM = "no-reply@birdeye.com"
    recipients = Email
    TO = recipients # must be a list
    SUBJECT = "IMPORTANT: Access Credential For %s" %(AccessType)
    html = '''<html>
    <head></head>
    <body>
    <p>Your Credentials are as below for $AccessType</p><br></br><p>Username : <b> $Username </b></p><p>Password : <b> $Pass </b></p><br></br> Please refer to URL : <b>https://devops.birdeye.com/accessRequest/</b> for host details </body>
    </html>'''
    filecontent="<br />Confidential: Acccess Credential"
    TEXT = Template(html).safe_substitute(AccessType=AccessType,Username=Username,Pass=Pass)
    # Prepare actual message
    message = """Subject: %s

    %s
    """ % (SUBJECT, filecontent)
    print message
    msg = MIMEMultipart('alternative')
    msg['Subject'] = SUBJECT
    msg['From'] = FROM
    msg['To'] = TO
    part1 = MIMEText(TEXT, 'html')
#    part1 = MIMEText(message, 'html')
    msg.attach(part1)
    # Send the mail
    server = smtplib.SMTP(SERVER)
#    server.sendmail(FROM, TO, message)
    server.sendmail(FROM,TO.split(','), msg.as_string())
    server.quit()

if __name__ == "__main__":
    triggermessage="PAID-API Deployment"
    status="Started"
    sendmail(status)
