#!/bin/bash 
ELB_NAME=$1
jenkins_url='https://ci.birdeye.com'
username='devops'
token='2ff2945ccab09483d5cc326702f261a3'
CRUMB=$(curl -k --user $username:$token $jenkins_url/crumbIssuer/api/xml?xpath=concat\(//crumbRequestField,%22:%22,//crumb\))
curl -kv -XPOST --user $username:$token -H "$CRUMB" $jenkins_url/job/restart_glassfish_api/buildWithParameters?ELB_NAME=$ELB_NAME
