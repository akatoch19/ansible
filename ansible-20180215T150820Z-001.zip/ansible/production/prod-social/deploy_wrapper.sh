#!/bin/bash 

export ANSIBLE_FORCE_COLOR=true
export ANSIBLE_HOST_KEY_CHECKING=False

red=`tput setaf 1`
green=`tput setaf 2`
reset=`tput sgr0`

ELB_NAME=$1

#Building Inventory servers under social elb
for i in `aws elb describe-instance-health --load-balancer-name ${ELB_NAME} --output text |  awk '{print $(NF-2)}'` ;
do
        aws ec2 describe-instances --instance-ids $i |jq -r '.Reservations[].Instances[].PublicIpAddress' >> inventory/Paid-Prod-Social
        echo "inventory created"
done


Ansible=`which ansible-playbook`
$Ansible -e 'host_key_checking=False' deploy.yaml --private-key=/var/lib/jenkins/ssh-keys/devops_rsa -u ubuntu -i inventory 

echo '' > inventory/Paid-Prod-Social
if [ $? -ne 0 ]
then
        echo "${red}Build failed , Check build logs" ${reset}
        exit 1
else
        echo "${green}Finished Build at " `date` ${reset}
fi
