#!/bin/bash 

export ANSIBLE_FORCE_COLOR=true
export ANSIBLE_HOST_KEY_CHECKING=False

red=`tput setaf 1`
green=`tput setaf 2`
reset=`tput sgr0`

ELB_NAME=${1}
restart_only_out_of_service=${2}
echo $restart_only_out_of_service

#Building Inventory of  Instances
if ${restart_only_out_of_service} ;
then
  echo -e "\nRestarting Glassfish on instances which are marked Out Of Serivce in ${ELB_NAME} ELB\n\n" ;
  for i in `aws elb describe-instance-health --load-balancer-name ${ELB_NAME} --output text | grep -vi InService |  awk '{print $(NF-2)}'` ;
  do
	aws ec2 describe-instances --instance-ids $i |jq -r '.Reservations[].Instances[].PublicIpAddress' >> inventory/Paid-Prod-API
  done
  echo "inventory created"
else
  echo -e "\nRestarting glassfish on all the instances behind ${ELB_NAME} ELB\n\n";
  for i in `aws elb describe-instance-health --load-balancer-name ${ELB_NAME} --output text | awk '{print $(NF-2)}'` ;
  do
        aws ec2 describe-instances --instance-ids $i |jq -r '.Reservations[].Instances[].PublicIpAddress' >> inventory/Paid-Prod-API
  done
  echo "inventory created"
fi

/usr/bin/ansible-playbook paidapi.yml --private-key=/var/lib/jenkins/ssh-keys/FreeProduct -u ubuntu -i inventory 
#/usr/bin/ansible-playbook paidapi.yml --private-key=/home/pratap/workdir/sshkeys/freeproduct.pem -u ubuntu -i inventory 


echo -e "\nMy Server to Me --->\nI AM GOING FOR POWERNAP OF 30 SEC TO RUN THE SAME BLOCK OF CODE.\nHUH!! :{ !! My developer does not know looping smartly!!\nTeach him coding.\nDo not waste CPU time as you waste your food.\nI can do lot better work than sleeping.\n\nMe To My Server --->\nOK Sir !!! I Agree!!\nI have asked RAJNI SIR to Program now onwards!!!\n\nMy Server reaction --->\n\nI am jokkkinnng %) !! I like sleeping 0;^)\n\n"
sleep 60
echo '' >inventory/Paid-Prod-API

for i in `aws elb describe-instance-health --load-balancer-name ${ELB_NAME} --output text | grep -vi InService |  awk '{print $(NF-2)}'` ;
do
        aws ec2 describe-instances --instance-ids $i |jq -r '.Reservations[].Instances[].PublicIpAddress' >> inventory/Paid-Prod-API
        echo "inventory created"
done

if [ `cat inventory/Paid-Prod-API | wc -l` -gt 1 ] ; then
/usr/bin/ansible-playbook paidapi.yml --private-key=/var/lib/jenkins/ssh-keys/FreeProduct -u ubuntu -i inventory 
fi


echo -e "\n\nNow My Server ---> (-_-)zzz\n\n"

