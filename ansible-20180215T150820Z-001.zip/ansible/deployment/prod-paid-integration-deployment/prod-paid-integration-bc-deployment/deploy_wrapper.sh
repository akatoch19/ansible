#!/bin/bash
#/bin/bash deploy_wrapper.sh ${USER_NAME} ${ACCESS_TYPE} ${EMAIL}

echo -e "Print all command line varabl\n"
echo -e"\n$1 $2 $3 $4 $5 $6\n"

export ANSIBLE_FORCE_COLOR=true
export ANSIBLE_HOST_KEY_CHECKING=False
myasg="$4"
red=`tput setaf 1`
green=`tput setaf 2`
reset=`tput sgr0`
#env=${1}
#Building Inventory servers under ASG
echo $myasg;
for i in `aws autoscaling describe-auto-scaling-groups --auto-scaling-group-name $myasg | grep -i instanceid  | awk '{ print $2}' | cut -d',' -f1| sed -e 's/"//g'`
do
aws ec2 describe-instances --instance-ids $i | grep -i PrivateIpAddress | awk '{ print $2 }' | head -1 | cut -d"," -f1 >> inventory/hosts
done;

Ansible=`which ansible-playbook`
$Ansible -e 'host_key_checking=False' deploy.yaml --private-key=/var/lib/jenkins/ssh-keys/devops_rsa -u devops -i inventory --extra-vars "jarName=$1 WORKSPACE=$2 service=$3 myasg=$4"

if [ $? -ne 0 ]
then
	echo "${red}Build failed , Check build logs" ${reset}
        exit 1
else
	echo "${green}Finished Build at " `date` ${reset}
fi
