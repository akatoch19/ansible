#!/bin/bash
#/bin/bash deploy_wrapper.sh ${USER_NAME} ${ACCESS_TYPE} ${EMAIL}

export ANSIBLE_FORCE_COLOR=true
export ANSIBLE_HOST_KEY_CHECKING=False

red=`tput setaf 1`
green=`tput setaf 2`
reset=`tput sgr0`
env=${1}


Ansible=`which ansible-playbook`
$Ansible deploy.yaml --private-key=/var/lib/jenkins/ssh-keys/devops_rsa -u devops -i inventory --extra-vars "Tomcatpath=$1  WarName=$2 WORKSPACE=$3 service=$4"

if [ $? -ne 0 ]
then
	echo "${red}Build failed , Check build logs" ${reset}
        exit 1
else
	echo "${green}Finished Build at " `date` ${reset}
fi
