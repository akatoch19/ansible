#!/bin/bash
#/bin/bash install_wrapper.sh 

export ANSIBLE_FORCE_COLOR=true
export ANSIBLE_HOST_KEY_CHECKING=False

red=`tput setaf 1`
green=`tput setaf 2`
reset=`tput sgr0`

myasg=$1;
region=$2;
zkhost=$3;

echo $myasg;
for i in `aws autoscaling describe-auto-scaling-groups --auto-scaling-group-name $myasg | grep -i instanceid  | awk '{ print $2}' | cut -d',' -f1| sed -e 's/"//g'`
do
x=$(aws ec2 describe-tags --filters "Name=resource-id,Values=$i" "Name=key,Values=Name" --region $region --output text | awk '{print $5}')
sed -i "/\[kafka_hosts\]/a $x" inventory/hosts
done;

IFS=', ' read -r -a array <<< "$zkhost"

for element in "${array[@]}"
do     
sed -i "/\[zookeeper_hosts\]/a $element" inventory/hosts
done;


Ansible=`which ansible-playbook`
$Ansible install.yml --private-key=/var/lib/jenkins/ssh-keys/devops_rsa -u devops -i inventory/hosts

if [ $? -ne 0 ]
then
	echo "${red}Build failed , Check build logs" ${reset}
        exit 1
else
	echo "${green}Finished Build at " `date` ${reset}
fi
