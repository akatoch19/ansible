#!/bin/bash
#/bin/bash deploy_wrapper.sh ${USER_NAME} ${ACCESS_TYPE} ${EMAIL}

export ANSIBLE_FORCE_COLOR=true
export ANSIBLE_HOST_KEY_CHECKING=False

red=`tput setaf 1`
green=`tput setaf 2`
reset=`tput sgr0`
workspace=${1}
debug='false'
if [[ ${3} == "development" ]]; then
  debug='true'
fi
Ansible=`which ansible-playbook`
$Ansible -e 'host_key_checking=False' deploy.yaml --private-key=/var/lib/jenkins/ssh-keys/devops_rsa -u ubuntu -i inventory --extra-vars "workspace=${1} domainname=${2} env=${3} debug=${debug}"

if [ $? -ne 0 ]
then
	echo "${red}Build failed , Check build logs" ${reset}
        exit 1
else
	echo "${green}Finished Build at " `date` ${reset}
fi
